package Agenda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Agenda{
// CONTROLLO METODI E VARIABILI STATIC ???
static private ArrayList<Appuntamento> agenda;
private final String nome;

public int numEl() {
	return agenda.size();
}

public Agenda(String nome) {
	this.nome = nome;
	agenda = new ArrayList<Appuntamento>();
	
}
 
//TESTATO OK ? 
public boolean cerca_per_nome(String nome_da_cercare) {
	
	for(Appuntamento app : agenda ) {
		if (app.getNome_persona().equals(nome_da_cercare)) {
			return true;
		}
	}
	return false;
}

public ArrayList<Appuntamento> getAgenda() {
	return agenda;
}

public String getNome() {
	return nome;
}

public void svuota_agenda() {
	agenda.clear();
}

// TESTATO OK     
public static boolean controllo_agenda(Appuntamento app) throws  AgendaException {
	boolean controllo = true;
	try {
	if(agenda.size() >= 2) {
			for (Appuntamento i: agenda) {
				if(i.getId() == app.getId()) {
					continue;
				}
				i.controllo_sovrapposizione(app);
			}
		}
		return controllo;
			} catch (AppuntamentoException e) {
				controllo = false;
				throw new AgendaException("Appuntamento sovrapposto in agenda");
			}
		}

//TESTATO OK
public boolean inserisci_appuntamento(Appuntamento app) throws AgendaException {
	boolean controllo = false;
	if(controllo_agenda(app)) {
		agenda.add(app);
		app.getId();
		controllo = true;
	}
	return controllo;
	
}

//CONTROLLO DELLA STRINGA NEL MATCHES da capire
public boolean isAlpha(String s) {
    return s != null && s.matches("^[a-zA-Z]*$");
}

// DA TESTARE ? FORSE GIA' TESTATO (OK)
public void cerca_appuntamento(String data_nome) throws   AgendaException {
	boolean nometrovato = false;
	try { 
	if (isAlpha(data_nome) )
	{
			for(Appuntamento i : agenda)
			{
				if(i.getNome_persona().equals(data_nome)) {
					System.out.println(i.toString());
					nometrovato = true;
				}
			}
			if(!nometrovato)
				System.out.println("Nome non trovato");	
	}
	else {
			Appuntamento tmp = new Appuntamento(data_nome, "00:00", 30, "", "");
				for(Appuntamento i : agenda)
				{
					if(i.getData().equals(tmp.getData())) {
						System.out.println(i.toString());
						nometrovato = true;
					}
				}
		}
	}
				catch (AppuntamentoException cerca_appuntamento){
					throw new AgendaException("Data inserita per la ricerca non valida");
	}
}

public ArrayList<Appuntamento> agenda_file_reader(String nome) throws AgendaException {
try    
{
	File file = new File(nome);
	BufferedReader br = new BufferedReader(new FileReader(file));
    String line;
    while ((line = br.readLine()) != null ) {
   
    String[] parts = line.split(";");
    if (controllo_agenda(new Appuntamento(parts[0], parts[1], Integer.parseInt(parts[2]) , parts[3], parts[4]))) {
    		   agenda.add(new Appuntamento(parts[0], parts[1], Integer.parseInt(parts[2]) , parts[3], parts[4]));
    }
    }
   
} catch (IOException e) {
    throw new AgendaException("File non valido");
} catch (NumberFormatException e) {
throw new AgendaException("Durata non valida, inserire un numero intero");
} catch (AppuntamentoException e) {
throw new AgendaException("Appuntamenti non validi");
}

return agenda;        
}

// TESTATO OK
public void agenda_file_writer(File file ) throws AgendaException {
	
	try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
		int x = 0;
		for(Appuntamento app: agenda) {
			bw.write("appuntamento " + x++ + ":\n");
			bw.append(app.toString() + "\n\n\n");
		} 
	}catch (IOException e){
		 throw new AgendaException("File non valido");
	} 
}

// FUNGE DA: CHAT GTP
public void elenca_per_data() {
	
class AppuntamentoComparator implements Comparator<Appuntamento> {
	
	public int compare(Appuntamento a1, Appuntamento a2) {
	    return a1.getData().compareTo(a2.getData());
	    }
	}
	
	Collections.sort(agenda, new AppuntamentoComparator());
}


public void stampa_appuntamenti() {
	System.out.println(this.nome + ":\n");
	
	for(Appuntamento i : agenda) {
//		System.out.println(i.getId() + " - " + i.getData() + ", " + i.getOrario() + ", " + i.getDurata() + ", " + i.getNome_persona() + ", " + i.getLuogo_appuntamento() + ";\n");
		System.out.println(i.toString());
	}
}

}//fine classe
