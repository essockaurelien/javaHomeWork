package Agenda;

public class AgendaException extends Exception {

	public AgendaException(String s) {
		super(s);
	}

}
