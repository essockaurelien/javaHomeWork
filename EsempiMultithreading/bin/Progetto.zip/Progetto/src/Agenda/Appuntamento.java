package Agenda;


import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Appuntamento {

	private LocalDate data;
	private LocalTime orario;
	private int durata;
	private String nome_persona;
	private String luogo_appuntamento;
	private int id;
	private static int  nextid = 0;
	public DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	
public Appuntamento(String data, String orario, int durata, String nome_persona, String luogo_appuntamento) throws AppuntamentoException {
	this.data = convalida_data(data);
	this.orario = trasforma_orario(orario);
	this.durata = durata;
	this.nome_persona = nome_persona.toLowerCase();
	this.luogo_appuntamento = luogo_appuntamento.toLowerCase();
	this.id = nextid++;
}

public int getId() {
	return id;
}


// TESTATO E FIXATO CASO CON LO STESSO ORARIO 
public boolean controllo_sovrapposizione(Appuntamento app) throws AppuntamentoException{
	
	boolean controllo = true;
	
	LocalTime INIZIO_appuntamento_nuovo = app.orario;
	LocalTime FINE_appuntamento_nuovo = app.orario.plusMinutes(app.durata);
	
	LocalTime INIZIO_appuntamento_esistente = this.orario;
	LocalTime FINE_appuntamento_esistente = this.orario.plusMinutes(this.durata);
	
	
	
	if(app.getData().equals(this.data) ) { //SE LA DATA DEL NUOVO APPUNTAMENTO (APP) COINCIDE CON LA DATA DELL'APPUNTAMENTO ESISTENTE
		if( (INIZIO_appuntamento_nuovo.isBefore(FINE_appuntamento_esistente) && // SE L'INIZIO DEL NUOVO APPUNTAMENTO VIENE PRIMA DELLA FINE DELL'APPUNTAMENTO ESISTENTE E
				INIZIO_appuntamento_nuovo.isAfter(INIZIO_appuntamento_esistente) ) || // L'INIZIO DEL NUOVO VIENE DOPO L'INIZIO DI QUELLO ESISTENTE OPPURE
				
				(INIZIO_appuntamento_nuovo.isBefore(INIZIO_appuntamento_esistente) && // L'INIZIO DEL NUOVO VIENE PRIMA DELL'INIZIO DI QUELLO ESISTENTE E 
						FINE_appuntamento_nuovo.isAfter(INIZIO_appuntamento_esistente) // LA FINE DEL NUOVO APP VIENE DOPO L'INIZIO DI QUELLO ESISTENTE E 
						 )// LA FINE DEL NUOVO APP VIENE PRIMA DELLA FINE DI QUELLO ESISTENTE OPPURE
				
				|| INIZIO_appuntamento_nuovo.equals(INIZIO_appuntamento_esistente) ) { //SE GLI ORARI COINCIDONO
			
			controllo = false;
			throw new AppuntamentoException("L'appuntamento si sovrappone a un altro"); 
		}
	}

	
	/*
	if(app.getData().equals(this.data) ) { //SE LA DATA DEL NUOVO APPUNTAMENTO (APP) COINCIDE CON LA DATA DELL'APPUNTAMENTO ESISTENTE
			if( (app.getOrario().isBefore(this.orario.plusMinutes(this.durata) ) && // SE L'INIZIO DEL NUOVO APPUNTAMENTO VIENE PRIMA DELLA FINE DELL'APPUNTAMENTO ESISTENTE E
				app.getOrario().isAfter(this.orario)) || // L'INIZIO DEL NUOVO VIENE DOPO L'INIZIO DI QUELLO ESISTENTE OPPURE
				app.getOrario().isBefore(this.orario) && // L'INIZIO DEL NUOVO VIENE PRIMA DELL'INIZIO DI QUELLO ESISTENTE E 
				app.getOrario().plusMinutes(app.getDurata()).isAfter(this.orario) && // LA FINE DEL NUOVO APP VIENE DOPO L'INIZIO DI QUELLO ESISTENTE E 
				app.getOrario().plusMinutes(app.getDurata()).isBefore(this.orario.plusMinutes(this.durata)) // LA FINE DEL NUOVO APP VIENE PRIMA DELLA FINE DI QUELLO ESISTENTE OPPURE
				|| app.getOrario().equals(this.orario) ) { //SE GLI ORARI COINCIDONO
						controllo = false;
						throw new AppuntamentoException("L'appuntamento si sovrappone a un altro"); 
				}
			}*/
	return controllo;
}

//TESTATO OK
public LocalTime trasforma_orario(String orario_utente) throws AppuntamentoException  {	
	DateTimeFormatter df = DateTimeFormatter.ofPattern("HH:mm");
	try {
	LocalTime orario = LocalTime.parse(orario_utente, df);
	return orario;
	}catch (DateTimeParseException e){
		throw new AppuntamentoException("Formato ora non valido");
	}
}

// TESTATO OK
public LocalDate convalida_data(String data_utente) throws AppuntamentoException {
	
	DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	try {
		LocalDate data = LocalDate.parse( data_utente, df);
		return data;
	}catch(DateTimeParseException e) {
		System.out.println("Formato data non valido");
		throw new AppuntamentoException("Formato data non valido");
	}
}


// TESTATO OK 
public void setData(String data) throws AppuntamentoException, AgendaException {
	try {
		
		//controllo che la data sia scritta bene
		Appuntamento tmp = new Appuntamento(data, this.orario.toString(), this.durata, this.nome_persona, this.luogo_appuntamento );
		
		//controllo che la data, se scritta bene, non si sovrapponga agli altri appuntamenti
		
		Agenda.controllo_agenda(tmp);
		
		
	}
	catch (AgendaException e){
		System.out.println("Errore! Data inserita per la modifica non valida!");
		throw new AppuntamentoException("Errore! Data inserita per la modifica non valida!");
	}
	
	// se non vengono sollevate exception allora modifico la data dell'appuntamento corrente
	this.data = convalida_data(data);
	
}

//TESTATO OK
public void setOrario(String orario) throws AppuntamentoException, AgendaException {
	try {
	Appuntamento tmp = new Appuntamento(this.data.format(df).toString(), orario, this.durata, this.nome_persona, this.luogo_appuntamento );
	
	Agenda.controllo_agenda(tmp);
	this.orario = trasforma_orario(orario);	
	}
	catch (AgendaException e){
		System.out.println("Errore! Orario inserito per la modifica non valida!");
		throw new AppuntamentoException("Errore! Orario inserito per la modifica non valida!");
	}
	catch (AppuntamentoException e){
		System.out.println("Errore! Orario inserito per la modifica non valida!");
		throw new AppuntamentoException("Errore! Orario inserito per la modifica non valida!");
	}
	
	
}

//TESTATO OK 
public void setDurata(int dur) throws AppuntamentoException, AgendaException {
	
	try {
		Appuntamento tmp = new Appuntamento(this.data.format(df).toString(), this.orario.toString(), dur, this.nome_persona, this.luogo_appuntamento );
		
		tmp.setId(this.id);
		
		System.out.println(tmp.toString());
		
		Agenda.controllo_agenda(tmp);
		
		this.durata = dur;
		}
		catch (AgendaException e){
			System.out.println("Errore! Durata inserita per la modifica non valida!");
			throw new AppuntamentoException("Errore! Durata inserita per la modifica non valida!");
		}
	
}

//TESTATO OK MA DA CONTROLLARE SE NOME INSERITO E' VALIDO


public void setId(int id) {
	this.id = id;
}

public void setLuogo_appuntamento(String luogo_appuntamento) {
	this.luogo_appuntamento = luogo_appuntamento;
}

public void setNome_persona(String nome_persona) {
	this.nome_persona = nome_persona;
}

public LocalDate getData() {
	return data;
}

public LocalTime getOrario() {
	return orario;
}

public int getDurata() {
	return durata;
}

public String getNome_persona() {
	return nome_persona;
}

public String getLuogo_appuntamento() {
	return luogo_appuntamento;
}

@Override
public String toString() {
    return this.id + ";" + this.data.format(df) + ";" + this.orario + ";" + durata + ";" + this.nome_persona + ";" + this.luogo_appuntamento + ";";
}



}//fine classe
