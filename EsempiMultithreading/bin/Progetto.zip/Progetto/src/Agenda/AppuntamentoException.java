package Agenda;

public class AppuntamentoException extends Exception {

	public AppuntamentoException(String string) {
		super(string);
	}

}
