package Agenda;

import java.util.ArrayList;
import java.util.Iterator;


public class GestoreAgenda /*implements Iterable<Agenda>*/{
	
//STILL NON ITERABILE (vedi riga 29)	
private static ArrayList<Agenda> elenco_agende = new ArrayList<Agenda>();

//Testato ok
public static Agenda crea_nuova_agenda(String nome) {
	
	Agenda a = new Agenda(nome);
	elenco_agende.add(a);
	
	return a;
	                                                                                                                
}

// DA TESTARE
public static void rimuovi_agenda(String nome) {

	Iterator<Agenda> it = elenco_agende.iterator();
	
		while (it.hasNext()) {
			String nome_da_cercare = it.next().getNome();
			if (nome_da_cercare.equals(nome)) {
				it.remove();
			}
		}
}

public static ArrayList<Agenda> getElenco_agende() {
	return elenco_agende;
}

public static void stampa() {

	for(Agenda a : elenco_agende) {
		a.stampa_appuntamenti();
	}

	}


public static void stampa_nome_agende() {
	System.out.println("\nAgende esistenti:\n");
	for(Agenda a : elenco_agende) {
		System.out.println("\n- " + a.getNome() + "\n");;
	}

}


}// fine classe gestore agende
