
package Agenda;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) throws AgendaException, AppuntamentoException {
		
		
		Scanner scelta_utente = new Scanner(System.in);
		
		System.out.println("Menu' principale:\n");
		System.out.println("Digita un numero per scegliere un'operazione:\n");

		System.out.println("1 - Visualizza elenco agende presenti;");
		System.out.println("2 - Crea una nuova agenda;");
		System.out.println("3 - Crea agenda da file;");
		System.out.println("4 - Apri agenda;");
		System.out.println("5 - Elimina agenda;");
		System.out.println("6 - EXIT;\n");
	
		System.out.print("Inserire numero operazione:");
		
		int scelta = scelta_utente.nextInt();
			String scelta_a_buffo = scelta_utente.nextLine();
		
		switch (scelta) {
		
		case 1:
			GestoreAgenda.stampa_nome_agende();
			main(args);
			
		case 2:
		
			System.out.print("Inserire nome della nuova agenda: ");
					
				String nomeAgenda =	scelta_utente.nextLine();
				
				for(Agenda a : GestoreAgenda.getElenco_agende()) {
					if(a.getNome().equals(nomeAgenda)) {
						System.out.println("\nAgenda gia' presente! Prova con un altro nome\n\n");
						main(args);
					}
				}
				Agenda agenda1 = GestoreAgenda.crea_nuova_agenda(nomeAgenda);
					if(agenda1 != null) {
						System.out.println("\n\nAgenda " + nomeAgenda + " creata con successo!");}
					else {
						System.out.println("Impossibile creare l'agenda " + nomeAgenda);
						main(args);}
				
				System.out.println("\n\n");
				main(args);
		
		case 3:
			System.out.println("Inserire nome della nuova agenda da caricare: ");
					String nome_Agenda_Da_File = scelta_utente.nextLine();
		
			System.out.println("Inserire NOME file da leggere: ");
					String file_da_leggere = scelta_utente.nextLine();
			
					
			Agenda agenda2 = GestoreAgenda.crea_nuova_agenda(nome_Agenda_Da_File);
				agenda2.agenda_file_reader(file_da_leggere);
				//agenda2.getAgenda(Agenda.) agenda_file_reader(file_da_leggere);
			
			main(args);
			
		case 4:
			
			if (GestoreAgenda.getElenco_agende().size() == 0 ) {
				System.out.println("\n\n\n");
				System.out.println("NESSUNA AGENDA ESISTENTE!");
				System.out.println("\n\n\n");
				main(args);
			}
			
//			System.out.println("\nAgende esistenti:\n");
			GestoreAgenda.stampa_nome_agende(); 
			System.out.println("\n\nInserire NOME di un agenda da selezionare o premi '0' per tornare al menu' principale: ");
			String nome_scelto = scelta_utente.nextLine();
					
				if(nome_scelto.equals("0")) {
						System.out.println("\n\n\n\n");
						main(args);
				}
					
			boolean nome_trovato = false;
					
			for (Agenda a: GestoreAgenda.getElenco_agende()) {
				
				if(a.getNome().equals(nome_scelto)) {
					
					nome_trovato = true;
					
					System.out.println("Agenda scelta: " + a.getNome() + "\n");
					System.out.println("Scegliere una delle opzioni: \n");
					System.out.println("1 - Inserire nuovo appuntamento;");
					System.out.println("2 - Modifica dati appuntamento;");
					System.out.println("3 - Cerca appuntamento;");
					System.out.println("4 - Mostra appuntamenti elencati per data;\n");
					System.out.println("5 - Indietro...");
					
					int scelta_utente_agenda = scelta_utente.nextInt();
					scelta_a_buffo = scelta_utente.nextLine();
					
					switch(scelta_utente_agenda) {
						case 1:
							
							System.out.println("\nInserire dati relativi al nuovo appuntamento: \n");
							
							System.out.print("\nData (gg-mm-aaaa):  ");
								String data_new_app = scelta_utente.nextLine();
							
							System.out.print("\nOra (HH-mm):  ");
								String ora_new_app = scelta_utente.nextLine();
							
							System.out.print("\nDurata in minuti:  ");
								int durata_new_app = scelta_utente.nextInt();
								scelta_a_buffo = scelta_utente.nextLine();
							
							System.out.print("\nNome persona con cui si ha l'appuntamento:  ");
								String nomePersona_new_app = scelta_utente.nextLine();
							
							System.out.print("\nLuogo dell'appuntamento:  ");
								String luogo_new_app = scelta_utente.nextLine();
							
							a.inserisci_appuntamento(new Appuntamento(data_new_app, ora_new_app, durata_new_app,
									nomePersona_new_app, luogo_new_app));
							
							System.out.println();
							
							main(args);
						
						case 2:
							
							System.out.println("Gli appuntamenti presenti sono: ");
							a.stampa_appuntamenti();
							
							System.out.println("\n\n");
							
							System.out.println("Scegliere appuntamento da modificare: ");
								int scelta_appuntamento = scelta_utente.nextInt();
							
							for(Appuntamento app : a.getAgenda()) {
								if(app.getId() == scelta_appuntamento) {
									System.out.println("Appuntamento scelto: ");	
									System.out.println(app.toString());
									
									System.out.println("Scegliere quale dato modificare tra: ");
									System.out.println("1 - Data: ");
									System.out.println("2 - Orario: ");
									System.out.println("3 - Durata: ");
									System.out.println("4 - Nome Persona: ");
									System.out.println("5 - Luogo: ");
									System.out.println("6 - INDIETRO ");
									
									System.out.println("Scegliere una modifica da effettuare: ");
									int scelta_modifica = scelta_utente.nextInt();
										scelta_a_buffo = scelta_utente.nextLine();
									
									switch(scelta_modifica) {
									 case 1:
										 System.out.println("Inserire nuova data (gg-mm-aaaa): ");
										 	String nuova_data = scelta_utente.nextLine();
										 
										 app.setData(nuova_data);
										 main(args);
										 
									 case 2:
										 System.out.println("Inserire nuovo orario (HH-mm): ");
										 	String nuovo_orario = scelta_utente.nextLine();
										 
										 app.setOrario(nuovo_orario);
										 main(args);
										 
									 case 3:
										 System.out.println("Inserire nuova durata (minuti): ");
										 	int nuova_duarata = scelta_utente.nextInt();
										 
										 app.setDurata(nuova_duarata);
										 main(args);
										 
									 case 4:
										 System.out.println("Inserire nuovo nome persona: ");
										 	String nuovo_nome = scelta_utente.nextLine();
										 
										 app.setNome_persona(nuovo_nome);
										 main(args);
										 
									 case 5:
										 System.out.println("Inserire nuovo luogo dell'appuntamento: ");
										 	String nuovo_luogo = scelta_utente.nextLine();
										 
										 app.setNome_persona(nuovo_luogo);
									 case 6:
										 System.out.println("\n\n\n");
										 main(args);
									}
								}
							}
							
							main(args);
							
						case 3:
							System.out.println("Inserire nome o data (hh-mm-aaaa) per ricercare l'appuntamento: ");
								String dato_modifica = scelta_utente.nextLine();
								a.cerca_appuntamento(dato_modifica);
								main(args);
						case 4:
							a.elenca_per_data();
							main(args);
						case 5:
							System.out.println("\n\n\n");
							main(args);
					}
					
					}
					
				}// fine agenda a 
			if(!nome_trovato) {
			System.out.println("\n\n\n\n");
			System.out.println("AGENDA : "+ nome_scelto +" NON TROVATA");
			System.out.println("\n\n\n\n");
			main(args);
			}
		
			main(args); // forse non serve
		case 5:
			
			if (GestoreAgenda.getElenco_agende().size() == 0 ) {
				System.out.println("\n\n\n\n");
				System.out.println("NESSUNA AGENDA ESISTENTE!");
				System.out.println("\n\n\n\n");
				main(args);
			}
			
			
			
				System.out.println("Inserire NOME agenda da eliminare?");
					String nome_agenda_da_eliminare = scelta_utente.nextLine();
					
					if(nome_agenda_da_eliminare.equals("0")) 
						System.out.println("\n\n\n\n");
					
				GestoreAgenda.rimuovi_agenda(nome_agenda_da_eliminare);
				
				System.out.println("Agenda " + nome_agenda_da_eliminare + " eliminata con successo!\n\n\n");
				main(args);
				
				
		
		case 6:
			System.out.println("Programma terminato!");
			System.exit(0);
			
		}//switch principale
			scelta_utente.close();
			
			
		
		}
	
	

	}
	

