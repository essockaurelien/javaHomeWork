package Agenda;

import java.util.ArrayList;
import java.util.Arrays;

public class MergeSort {
    public static void main() throws AgendaException, AppuntamentoException {
        Agenda agenda = GestoreAgenda.crea_nuova_agenda("agenda"); 
        agenda.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda.inserisci_appuntamento(new Appuntamento("24-02-2001","19:35",30,"andrija","ufficio"));
		agenda.inserisci_appuntamento(new Appuntamento("02-02-2001","19:35",30,"luca","ufficio"));
		agenda.inserisci_appuntamento(new Appuntamento("01-02-2001","19:35",30,"luca","ufficio"));
		agenda.inserisci_appuntamento(new Appuntamento("15-02-2001","19:35",30,"luca","ufficio"));
        mergeSort(agenda.getAgenda());
        System.out.println(agenda.toString());
    }

    public static void mergeSort(ArrayList<Appuntamento> agenda) {
        if (agenda.size() > 1) {
        	ArrayList<Appuntamento> agendaLeft = leftHalf(agenda);
        	ArrayList<Appuntamento> agendaRight = rightHalf(agenda);
            mergeSort(agendaLeft);
            mergeSort(agendaRight);
            merge(agenda, agendaLeft, agendaRight);
        }
    }

    public static ArrayList<Appuntamento> leftHalf(ArrayList<Appuntamento> agenda) {
        int size1 = agenda.size() / 2;
        ArrayList<Appuntamento> agendaleft = new ArrayList<Appuntamento>();
        for (int i = 0; i < size1; i++) {
        	agendaleft.add(agenda.get(i));
        }
        return agendaleft;
    }

    public static ArrayList<Appuntamento> rightHalf(ArrayList<Appuntamento> agenda) {
    	ArrayList<Appuntamento> agendaright = new ArrayList<Appuntamento>();
        int size1 = agenda.size() / 2;
        int size2 = agenda.size() - size1;
        for (int i = 0; i < size2; i++) {
        	agendaright.add(agenda.get(i+size1));
        }
        return agendaright;
    }

    public static void merge(ArrayList<Appuntamento> result, ArrayList<Appuntamento> left, ArrayList<Appuntamento> right) {
        
    	int i1 = 0;
        int i2 = 0;
        
        for (int i = 0; i < result.size(); i++) {
            if (i2 >= right.size() || (i1 < left.size() && (left.get(i1).getData().isBefore(right.get(i2).getData()) || left.get(i1).getData().isEqual(right.get(i2).getData())  )  )) {
                result.add(left.get(i1));
                i1++;
            } else {
            	result.add(right.get(i2));
                i2++;
            }
        }
    }
}
