package Test;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Agenda.Agenda;
import Agenda.AgendaException;
import Agenda.Appuntamento;
import Agenda.AppuntamentoException;
import Agenda.GestoreAgenda;


public class AgendaTest {

	
	// TEST FUNZIONANTI
/*
	@BeforeEach
	void test_crea() {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		assertTrue(agenda1 != null); 
	}
		
	@Test
	void test_InserimentoAppuntamenti_formatoDataNonValido() {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");

		AppuntamentoException ex = assertThrows(AppuntamentoException.class, () ->
	{
		agenda1.inserisci_appuntamento(new Appuntamento("210-02-2001","20:10",30,"luca","ufficio"));
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
	
	}); // EX = FORMATO DATA NON VALIDO
		
		
		
		assertEquals("Formato data non valido", ex.getMessage() );
		assertTrue(agenda1.getNome().equals("agenda1") );
		
	}
	
	@Test
	void test_InserimentoAppuntamenti_formatoOraNonValido() {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");

		AppuntamentoException ex = assertThrows(AppuntamentoException.class, () ->
	{
		agenda1.inserisci_appuntamento(new Appuntamento("210-02-2001","200:10",30,"luca","ufficio")); //lancia l'eccezione
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
	
	}); // EX = FORMATO ORA NON VALIDO
		
		assertEquals("Formato data non valido", ex.getMessage() );
		assertTrue(agenda1.getNome().equals("agenda1") );
		
	}
	
	@Test
	void test_InserimentoAppuntamenti_appuntamentoSovrapposto() {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		AgendaException exData = assertThrows(AgendaException.class, () ->
		{
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:31",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		
		}); // EX DATA = L'APPUNTAMENTO SI SOVRAPPONE A UN ALTRO
		
		assertEquals("Appuntamento sovrapposto in agenda", exData.getMessage() );
		//System.out.println(agenda1.getAgenda());
		
	}
	
	@Test
	void test_InserimentoGiusto() throws AgendaException, AppuntamentoException {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda1.inserisci_appuntamento(new Appuntamento("21-02-2001","10:00",30,"luca","ufficio"));
		
		assertTrue(agenda1.numEl() == 2);
	}
	
	@Test
	void test_InserimentoAppuntamentoSbagliato() throws AgendaException, AppuntamentoException{
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		AgendaException ex = assertThrows(AgendaException.class, () ->
		{
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:15",30,"luca","ufficio"));
			
		});
		
		assertEquals("Appuntamento sovrapposto in agenda", ex.getMessage());
		//assertTrue(agenda1.getAgenda().get(0).getData().toString().equals("2022-05-20"));
	}
	
	@Test
	void test_SetData_giusto() throws AgendaException, AppuntamentoException {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda1.inserisci_appuntamento(new Appuntamento("21-02-2001","10:00",30,"luca","ufficio"));
		
		agenda1.getAgenda().get(0).setData("20-05-2022");
		
		assertTrue(agenda1.getAgenda().get(0).getData().toString().equals("2022-05-20"));
	}

	@Test
	void test_SetData_errato() {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		AppuntamentoException ex = assertThrows(AppuntamentoException.class, () ->
		{
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("21-02-2001","20:15",30,"luca","ufficio"));
			
			agenda1.getAgenda().get(1).setData("20-02-2001");
				
		});
		
		assertEquals("Errore! Data inserita per la modifica non valida!", ex.getMessage());
	}
	
	@Test
	void test_SetOrario_Sbagliato() {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		AppuntamentoException ex = assertThrows(AppuntamentoException.class, () ->
		{
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","19:00",30,"luca","ufficio"));
			
			agenda1.getAgenda().get(1).setOrario("20:25");
				
		});
		assertEquals("Errore! Orario inserito per la modifica non valida!", ex.getMessage());
	}
	
	@Test
	void test_SetOrario_Corretto() throws AgendaException, AppuntamentoException{

		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("21-02-2001","20:15",30,"luca","ufficio"));
			
			agenda1.getAgenda().get(1).setOrario("10:00");
		
		assertEquals("10:00", agenda1.getAgenda().get(1).getOrario().toString());
}
	
	@Test
	void test_SetNomePersona() throws AgendaException, AppuntamentoException {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","19:35",30,"luca","ufficio"));
		
		agenda1.getAgenda().get(1).setNome_persona("alessandro");
			
		assertEquals(agenda1.getAgenda().get(1).getNome_persona(),"alessandro");
		
	}
	
	@Test
	void test_SetLuogoAppuntamento() throws AgendaException, AppuntamentoException {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","19:35",30,"luca","ufficio"));
		
		agenda1.getAgenda().get(1).setLuogo_appuntamento("casa");
			
		assertEquals(agenda1.getAgenda().get(1).getLuogo_appuntamento(),"casa");
	}
	
	@Test
	void test_elencaPerData() throws AgendaException, AppuntamentoException {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda1.inserisci_appuntamento(new Appuntamento("24-02-2001","19:35",30,"luca","ufficio"));
		agenda1.inserisci_appuntamento(new Appuntamento("02-02-2001","19:35",30,"luca","ufficio"));
		agenda1.inserisci_appuntamento(new Appuntamento("01-02-2001","19:35",30,"luca","ufficio"));
		agenda1.inserisci_appuntamento(new Appuntamento("15-02-2001","19:35",30,"luca","ufficio"));
		
		agenda1.elenca_per_data();
		
		System.out.println(agenda1.toString());
	}
	
	// TEST CHE DANNO PROBLEMI
	
	@Test
	void test_SetDurata_Giusto() throws AgendaException, AppuntamentoException {
		
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			
			agenda1.inserisci_appuntamento(new Appuntamento("25-02-2021","10:00",30,"luca","ufficio"));
			
			System.out.println(agenda1.toString());
			
			agenda1.getAgenda().get(0).setDurata(1);
				
			assertEquals(agenda1.getAgenda().get(0).getDurata(), 1);
				
	}
	

	@Test
	void test_SetDurata_Sbagliato() {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		AppuntamentoException ex = assertThrows(AppuntamentoException.class, () ->
		{
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","19:35",30,"luca","ufficio"));
			
			agenda1.getAgenda().get(1).setDurata(60);
				
		});
		
		assertEquals("Errore! Durata inserita per la modifica non valida!", ex.getMessage());
		
	}
	*/
	@Test
	void test_ScritturaSuFile() throws AgendaException, AppuntamentoException, IOException{
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda scritta su file");
		
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		agenda1.inserisci_appuntamento(new Appuntamento("25-03-2002","21:35",30,"luca","ufficio"));
		agenda1.inserisci_appuntamento(new Appuntamento("24-08-2003","11:35",30,"andrija","casa"));
		agenda1.inserisci_appuntamento(new Appuntamento("25-07-2004","09:35",30,"alessandro","universita'"));
		agenda1.inserisci_appuntamento(new Appuntamento("21-03-2010","07:35",30,"martinaNails","Nel mio bagno"));
		agenda1.inserisci_appuntamento(new Appuntamento("22-04-2008","18:35",30,"marcelloFasano","novara"));
		agenda1.inserisci_appuntamento(new Appuntamento("20-10-2006","14:35",30,"miPadre","molise"));
		
		File f = new File("Martina_nails.txt");
		
		f.createNewFile();
		
		agenda1.agenda_file_writer(f);
		
		ArrayList<Appuntamento> agenda2 = new ArrayList<Appuntamento>();

		Agenda agenda3 = GestoreAgenda.crea_nuova_agenda("prova");
		
		agenda3.agenda_file_reader("Prova_Scrittura.txt");
		
		agenda3.stampa_appuntamenti();
		
		assertTrue(agenda2 != null);
		assertTrue(agenda3.numEl() == agenda1.numEl());
		assertTrue(f.exists());
	}
	
	@Test
	void test_LetturaFile() {
		Agenda agenda1 = GestoreAgenda.crea_nuova_agenda("agenda1");
		
	}
	/*
	@Test
	void stampa() throws AppuntamentoException, AgendaException {
		Agenda a = GestoreAgenda.crea_nuova_agenda("agenda1");
		
		Appuntamento v = new Appuntamento("19-02-2001","20:30",30,"lorenzo","Aula");
		Appuntamento b = new Appuntamento("21-02-2001","20:30",30,"lorenzo","Aula");
		Appuntamento c = new Appuntamento("22-02-2001","20:30",30,"lorenzo","Aula");
		Appuntamento h = new Appuntamento("10-02-2001","20:30",30,"lorenzo","Aula");
		
		a.inserisci_appuntamento(v);
		a.inserisci_appuntamento(b);
		a.inserisci_appuntamento(c);
		a.inserisci_appuntamento(h);

		
		GestoreAgenda.stampa();
		
	}*/
	
	
	
	
	
	
	
	
	
	
	
	
	}//fine classe test






