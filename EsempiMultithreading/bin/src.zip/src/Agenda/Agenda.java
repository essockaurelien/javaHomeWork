package Agenda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;


public class Agenda{

	// CONTROLLO METODI E VARIABILI STATIC ???
static private ArrayList<Appuntamento> agenda;
private final String nome;


public Agenda(String nome) {
	this.nome = nome;
	agenda = new ArrayList<Appuntamento>();
	
}

public int numEl() {
	return agenda.size();
}
 
//TESTATO OK ? 
public boolean cerca_per_nome(String nome_da_cercare) {
	
	for(Appuntamento app : agenda ) {
		if (app.getNome_persona().equals(nome_da_cercare)) {
			return true;
		}
	}
	return false;
}

//CONTROLLARE SE SERVE
public  ArrayList<Appuntamento> getAgenda() {
	return agenda;
}

public String getNome() {
	return nome;
}

public void svuota_agenda() {
	agenda.clear();
}

//da mettere in appuntamento
/*
static public int controllo_sovrapposizione(Appuntamento app) throws AppuntamentoException{
	
	for (Appuntamento i : agenda) {
		if(app.getData().equals(i.getData()) ) {
			if(app.getOrario().isBefore(i.getOrario().plusMinutes(i.getDurata())) &&
					app.getOrario().isAfter(i.getOrario()) ) {
						throw new AppuntamentoException("L'appuntamento si sovrappone a un altro"); 
				}
			}
	}
	return 0;
}*/

// DA TESTARE DOPO SPOSTAMENTO DEL METODO CONTROLLO IN APPUNTAMENTO
public boolean controllo_agenda(Appuntamento app) throws AgendaException {
	boolean controllo = true;
	try {
		for (Appuntamento i: agenda) 
				i.controllo_sovrapposizione(app);
			} catch (AppuntamentoException e) {
				controllo = false;
				throw new AgendaException("Appuntamento sovrapposto (da agenda.controllo_agenda) ");
			}
			return controllo; 
		}
	


//DA TESTARE DOPO MODIFICA DEL METODO CONTROLLO AGENDA 
public boolean inserisci_appuntamento(Appuntamento app) throws AgendaException{
	boolean controllo = false;
	if(controllo_agenda(app)) {
		agenda.add(app);
		controllo = true;
	}
	return controllo;
	
}

//CONTROLLO DELLA STRINGA NEL MATCHES 
public boolean isAlpha(String s) {
    return s != null && s.matches("^[a-zA-Z]*$");
}

// DA TESTARE ? FORSE GIA' TESTATO (OK)
public void cerca_appuntamento(String data_nome) throws  AppuntamentoException {
	boolean nometrovato = false;
	try { 
	if (isAlpha(data_nome) )
	{
			for(Appuntamento i : agenda)
			{
				if(i.getNome_persona().equals(data_nome)) {
					System.out.println(i.toString());
					nometrovato = true;
				}
			}
			if(!nometrovato)
				System.out.println("Nome non trovato");	
	}
	else {
		
			Appuntamento tmp = new Appuntamento(data_nome, "00:00", 30, "", "");
				for(Appuntamento i : agenda)
				{
					if(i.getData().equals(tmp.getData())) {
						System.out.println(i.toString());
						nometrovato = true;
					}
				}
		}
	}
				catch (AppuntamentoException cerca_appuntamento){
					throw new AppuntamentoException("Data inserita per la ricerca non valida");
	}
}



//DA TESTARE E CONTROLLARE I MESSAGGI DELLE ECCEZIONI
public ArrayList<Appuntamento> agenda_file_reader(File file) throws AgendaException {
	
        ArrayList<Appuntamento> lines = new ArrayList<>();
        try    
        	{
        	BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null ) {
            	
            	String[] parts = line.split(";");
            	
            	lines.add(new Appuntamento(parts[0], parts[1], Integer.parseInt(parts[2]) , parts[3], parts[4]));
            			
            }
        } catch (IOException e) {
            throw new AgendaException("File non valido");
        } catch (NumberFormatException e) {
        	throw new AgendaException("Durata non valida, inserire un numero intero");
        } catch (AppuntamentoException e) {
        	throw new AgendaException("Appuntamenti non validi");
        }
       return lines;        
}


// MAI TESTATO, da modificare sicuramente l'eccezione lanciata
public void agenda_file_writer(File file ) throws AgendaException {
	
	try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
		for(Appuntamento app: agenda) {
			bw.write(app.toString());
		} 
	}catch (IOException e){
		 throw new AgendaException("File non valido");
	} 
}


// ANDRIJA WORK ON
// MAI TESTATO METODO PROVVISORIO DA: CHAT GTP
public void elenca_per_data() {
	
class AppuntamentoComparator implements Comparator<Appuntamento> {
	public int compare(Appuntamento a1, Appuntamento a2) {
	    return a1.getData().compareTo(a2.getData());
	    }
	}
	
	Collections.sort(agenda, new AppuntamentoComparator());
	

}

}//fine classe
