package Agenda;

public class AgendaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AgendaException(String s) {
		super(s);
	}

}
