package Agenda;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Appuntamento {

	private LocalDate data;
	private LocalTime orario;
	private int durata;
	private String nome_persona;
	private String luogo_appuntamento;

public Appuntamento(String data, String orario, int durata, String nome_persona, String luogo_appuntamento) throws AppuntamentoException {
	this.data = convalida_data(data);
	this.orario = trasforma_orario(orario);
	this.durata = durata;
	this.nome_persona = nome_persona.toLowerCase();
	this.luogo_appuntamento = luogo_appuntamento;
}

// DA TESTARE
public boolean controllo_sovrapposizione(Appuntamento app) throws AppuntamentoException{
	boolean controllo = true;
		if(app.getData().equals(this.data) ) {
			if(app.getOrario().isBefore(this.orario.plusMinutes(this.durata)) &&
					app.getOrario().isAfter(this.orario) ) {
						controllo = false;
						throw new AppuntamentoException("L'appuntamento si sovrappone a un altro"); 
				}
			}
	return controllo;
}

//TESTATO OK
public LocalTime trasforma_orario(String orario_utente) throws AppuntamentoException  {	
	DateTimeFormatter df = DateTimeFormatter.ofPattern("HH:mm");
	try {
	LocalTime orario = LocalTime.parse(orario_utente, df);
	return orario;
	}catch (DateTimeParseException e){
		throw new AppuntamentoException("Formato ora non valido");
	}
}

// TESTATO OK
public LocalDate convalida_data(String data_utente) throws AppuntamentoException {
	
	DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	try {
		LocalDate data = LocalDate.parse( data_utente, df);
		return data;
	}catch(DateTimeParseException e) {
		System.out.println("Formato data non valido");
		throw new AppuntamentoException("Formato data non valido");
	}
}

// DA TESTARE
public void setData(LocalDate date) throws AppuntamentoException {
	try {
	Appuntamento tmp = new Appuntamento(date.toString(), this.orario.toString(), this.durata, this.nome_persona, this.luogo_appuntamento );
	
	controllo_sovrapposizione(tmp);
		
	}
	catch (AppuntamentoException e){
		System.out.println("Errore! Data inserita per la modifica non valida!");
		throw new AppuntamentoException("Errore! Data inserita per la modifica non valida!");
	}
	
	this.data = convalida_data(date.toString());

}

//DA TESTARE
public void setOrario(String orario) throws AppuntamentoException {
	try {
	Appuntamento tmp = new Appuntamento(this.data.toString(), orario, this.durata, this.nome_persona, this.luogo_appuntamento );
	
	controllo_sovrapposizione(tmp);
		
	}
	catch (AppuntamentoException e){
		System.out.println("Errore! Orario inserito per la modifica non valida!");
		throw new AppuntamentoException("Errore! Orario inserito per la modifica non valida!");
	}
	this.orario = trasforma_orario(orario);
}


//DA TESTARE
public void setDurata(int durata) throws AppuntamentoException {
	
	try {
		Appuntamento tmp = new Appuntamento(this.data.toString(), this.orario.toString(), durata, this.nome_persona, this.luogo_appuntamento );
		controllo_sovrapposizione(tmp);
		}
		catch (AppuntamentoException e){
			System.out.println("Errore! Durata inserita per la modifica non valida!");
			throw new AppuntamentoException("Errore! Durata inserita per la modifica non valida!");
		}
	this.durata = durata;
}

public void setNome_persona(String nome_persona) {
	
	this.nome_persona = nome_persona;
}

public void setLuogo_appuntamento(String luogo_appuntamento) {
	this.luogo_appuntamento = luogo_appuntamento;
}

public LocalDate getData() {
	return data;
}

public LocalTime getOrario() {
	return orario;
}

public int getDurata() {
	return durata;
}

public String getNome_persona() {
	return nome_persona;
}

public String getLuogo_appuntamento() {
	return luogo_appuntamento;
}

@Override
public String toString() {
	DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	return "[" + this.data.format(df) + ", " + this.orario + ", " + durata + ", " + this.nome_persona + ", " + this.luogo_appuntamento + "]";
}

}//fine classe
