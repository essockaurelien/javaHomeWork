package Agenda;

public class AppuntamentoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AppuntamentoException(String string) {
		super(string);
	}

}
