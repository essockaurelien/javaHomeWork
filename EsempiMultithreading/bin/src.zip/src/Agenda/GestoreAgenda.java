package Agenda;

import java.util.HashMap;

public class GestoreAgenda {
	
   //STILL NON ITERABILE (vedi riga 29)	
   private static HashMap<String, Agenda> elenco_agende = new HashMap<String, Agenda>();


   //DA TESTARE
   public static Agenda crea_nuova_agenda(String nome) {
	
	Agenda a = new Agenda(nome);
	elenco_agende.put(nome, a);
	
	return a;
	
   }

   // DA TESTARE
   public static void rimuovi_agenda(String nome) {
	elenco_agende.remove(nome);
   }

   public void stampa_agende() {
	for(Agenda a : elenco_agende) {
	System.out.println(elenco_agende);

	}
}

} 