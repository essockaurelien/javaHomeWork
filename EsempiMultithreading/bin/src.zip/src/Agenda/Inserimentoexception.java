package Agenda;

public class Inserimentoexception extends Exception {
	

	
	private static final long serialVersionUID = 1L;

	public Inserimentoexception(String s) {
		super(s);
	}
	
}
