package Test;




import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import Agenda.Agenda;
import Agenda.Appuntamento;
import Agenda.Inserimentoexception;

public class AgendaTest {
	
	@Test
	void testcrea() {
		Agenda agenda1 = new Agenda("agenda1");
		Inserimentoexception ex = assertThrows(Inserimentoexception.class, () ->
	{
		agenda1.inserisci_appuntamento(new Appuntamento("210-02-2001","20:10",30,"luca","ufficio"));
		agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
	
	}); // EX = FORMATO DATA NON VALIDO
		
		Inserimentoexception exData = assertThrows(Inserimentoexception.class, () ->
		{
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:10",30,"luca","ufficio"));
			agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:30",30,"lorenzo","Aula"));
		
		}); // EX DATA = L'APPUNTAMENTO SI SOVRAPPONE A UN ALTRO
		
		assertEquals("Formato data non valido", ex.getMessage() );
		assertEquals("L'appuntamento si sovrappone a un altro", exData.getMessage() );
		assertTrue(agenda1.getAgenda().get(0).getData().toString().equals("2001-02-20"));
		assertTrue(agenda1.getNome().equals("agenda1") );
		
		//Agenda a = GestoreAgenda.crea_nuova_agenda("coiap");
		
		
	}

	/*
	@Test
	void testAggiungi() {
		Agenda agenda1 = new Agenda("agenda1");
		DateTimeParseException ex = assertThrows(DateTimeParseException.class, () ->
		{
			//agenda1.inserisci_appuntamento(new Appuntamento("20-02-2001","20:10",30,"luca","ufficio"));
			agenda1.inserisci_appuntamento(new Appuntamento("200000-05737532-20tjhrftjsy01","280:380",30,"lorenzo","Aula"));
		
		});
			assertEquals("Formato data non valido", ex.getMessage() );
			
			assertEquals("L'appuntamento si sovrappone a un altro", ex.getMessage() );
			assertTrue(agenda1.getAgenda().get(0).getData().toString().equals("2001-02-20"));
			assertTrue(agenda1.getNome().equals("agenda1") );
		}

	*/
	
	/*
	@Test  // NON FUNZIONA
	void testEliminaAgenda() {
		Agenda agenda1 = new Agenda("agenda1");
		System.out.println("agenda prima: " + agenda1) ;
		agenda1.cancella_agenda(agenda1);
		System.out.println("agenda dopo: " + agenda1) ;
		System.out.println("agenda dopo: " + agenda1.getNome()) ;
		
	}
	

		//}//);
		
		//Appuntamento a= new Appuntamento("01-05-2017", "16:20", 30, "lorenzo", "lavoro");
		
		//assertEquals("L'appuntamento si sovrappone a un altro", ex.getMessage() );
		agenda1.cerca_appuntamento("luca");
		System.out.println(agenda1.numEl());
	}
	
	*/
	
	
	
	
	}
	
	
	
	


