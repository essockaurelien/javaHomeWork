package codice;

public class AgendaException extends Exception {

	/**
	 * 
	 * @author essock
	 */
	private static final long serialVersionUID = 1L;
	
	public AgendaException(String str) {
		super(str);
	}

}
