package codice;

/**
 * 
 * 
 * @author essock
 * */
public class AppuntamentoException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public AppuntamentoException(String str) {
		super(str);
	}

}
