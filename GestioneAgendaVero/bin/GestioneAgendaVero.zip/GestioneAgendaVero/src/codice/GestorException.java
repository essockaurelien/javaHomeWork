package codice;

public class GestorException extends Exception{
	
	
	
	private static final long serialVersionUID = 1L;
    /**
     * 
     * @param str
     */
	public GestorException(String str) {
		super(str);
	}
}
